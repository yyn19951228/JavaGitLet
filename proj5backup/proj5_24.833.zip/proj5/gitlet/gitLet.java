package gitlet;


import edu.princeton.cs.algs4.ST;
import org.omg.PortableInterceptor.SYSTEM_EXCEPTION;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;

/**
 * Created by yangyining on 03/05/2017.
 */
public class gitLet implements Serializable {

    private static final String GITLETFILE = ".gitlet/";
    private static final String STAGINE_DIR = "staged/";
    private static final String COMMIT_DIR = "commit/";

    // branches name and CNode ID
    private HashMap<String,String> branches;


    //CNode ID and CNode
    //CNode: commitNode, store the commit information
    private HashMap<String,CNode> commitTree;

    //untracked files name
    private HashSet<String> untracked;

    //stated files name
    private HashSet<String> staged;

    //removied files name
    private HashSet<String> removed;

    //modification and unstaged
    private HashSet<String> unstagedWhileTracked;

    //tracked files
    private HashSet<String> tracked;


    //the head of one branch
    private CNode head;


    private String currentBranch;


    gitLet() {
        branches = new HashMap<>();
        commitTree = new HashMap<>();
        untracked = new HashSet<>();
        staged = new HashSet<>();
        removed = new HashSet<>();
        unstagedWhileTracked = new HashSet<>();
        tracked = new HashSet<>();
    }


    void gitletInit() {
        File gitletFile = new File(GITLETFILE);
        if (gitletFile.exists()) {
            System.out.println("A gitlet version-control system already exists in the current directory.");
        } else {
            //create .gitlet/ and commit initial
            gitletFile.mkdirs();

            //create .staged
            File statedFIle = new File(GITLETFILE + STAGINE_DIR);
            statedFIle.mkdirs();

            //create .commit
            File commitFIle = new File(GITLETFILE + COMMIT_DIR);
            commitFIle.mkdirs();

            currentBranch = "master";
            commitInit("initial commit");

            scanUntrackedFiles();

        }
    }

    void gitletAdd(String fileName) {
        if (untracked.contains(fileName)) {
            untracked.remove(fileName);

        }
        if (fileName == null) {
            return;
        }

        File toBeAdded = new File(fileName);
        if (!toBeAdded.exists()) {
            System.err.print("File does not exist.");
            return ;
        }

        File src = new File(fileName);

        //check if the file has been modified
        //compared with current commit
        String currentCommitFilePath = GITLETFILE + COMMIT_DIR + head.getID() + "/" + fileName;
        File currentCommitFile = new File(currentCommitFilePath);
        if (currentCommitFile.exists()) {
            if (compareFiles(src,currentCommitFile)) {
                System.out.println("no change");
                return;
            }
        }



        staged.add(fileName);

        tracked.add(fileName);


        File dest = new File(GITLETFILE + STAGINE_DIR + fileName);

        if (!dest.exists()) {
            dest.mkdirs();
        }
        //add operator
        //copy the staged file into the .gitlet/staged/
        try {
            Files.copy(src.toPath(), dest.toPath(), StandardCopyOption.REPLACE_EXISTING);
        }catch (IOException e) {
            e.printStackTrace();
        }





    }

    void gitletCommit(String message) {

        if (staged.isEmpty()) {
            System.out.println("No changes added to the commit.");
            return ;
        }
        if (message.equals("")) {
            System.out.println("Please enter a commit message.");
            return ;
        }

        Date currentDateObject = new Date();

        CNode toCommit = new CNode();


        String parentsID = head.getID();
        //to commit
        toCommit.commit(parentsID,head,message,staged,currentDateObject);

        head = toCommit;


        String toSHA = toCommit.getID() + toCommit.getParentsID() + toCommit.getMessages() + toCommit.getCommitDate();

        String commitSHA = Utils.sha1(toSHA);


        transferFromStagedToCommit(commitSHA);
        staged.clear();

        toCommit.setID(commitSHA);
        commitTree.put(commitSHA,toCommit);
        branches.put(currentBranch,commitSHA);

    }

    void gitletRm(String fileName) {
        if (!staged.contains(fileName) && !tracked.contains(fileName)) {
            System.out.println("No reason to remove the file.");
            return ;

        }

        if (staged.contains(fileName)) {
            //delete this file from .gitlet/stage/ file and unstage it

            staged.remove(fileName);

            String stagePath = GITLETFILE + STAGINE_DIR + fileName;
            File toDelete = new File(stagePath);
            if (toDelete.exists()) {
                toDelete.delete();
            }

            untracked.add(fileName);
        } else {
            tracked.remove(fileName);
            untracked.add(fileName);
        }
    }



    void gitletLog() {

        CNode toLog = head;
        while(toLog != null) {
            System.out.println("===");
            System.out.println("Commit " + toLog.getID());
            System.out.println(toLog.getCommitDate());
            System.out.println(toLog.getMessages());
            System.out.println();

            toLog = toLog.getParent();
        }

    }

    void gitletGlobalLog() {
        for (CNode toLog: commitTree.values()) {
            System.out.println("===");
            System.out.println("Commit " + toLog.getID());
            System.out.println(toLog.getCommitDate());
            System.out.println(toLog.getMessages());
            System.out.println();
        }
    }

    void gitletFind(String commitMessage) {
        CNode toFind = head;
        HashSet<String> r = new HashSet<>();
        while(toFind != null) {
            String id = toFind.getID();
            String message = toFind.getMessages();
            if (message.equals(commitMessage)) {
                r.add(id);
            }
            toFind = toFind.getParent();
        }
        System.out.println(r);
    }

    void gitletStatus() {
        System.out.println("=== Branches ===");
        for (String branchName: branches.keySet()) {
            if (branchName.equals(currentBranch)) {
                System.out.print("*");
                System.out.println(branchName);
            }
        }
        System.out.println();

        System.out.println("=== Staged Files ===");
        for (String fileName: staged) {
            System.out.println(fileName);
        }
        System.out.println();

        System.out.println("=== Removed Files ===");
        for (String fileName: removed) {
            System.out.println(fileName);
        }
        System.out.println();

        System.out.println("=== Modifications Not Staged For Commit ===");
        for (String fileName: unstagedWhileTracked) {

            System.out.println(fileName);
        }
        System.out.println();

        System.out.println("=== Untracked Files ===");
        for (String fileName: untracked) {
            System.out.println(fileName);
        }


    }

    void gitletCheckout(String... args) {

        if (args.length == 3) {
            //checkout -- [file name]

            String checkOutFileName = args[2];
            //check if file exists in previous commit?
            HashSet<String> prevCommit = head.getFileNames();
            if (!prevCommit.contains(checkOutFileName)) {
                System.out.println("File does not exist in that commit.");
                return ;
            }
            String sha = head.getID();
            String filePath = GITLETFILE + COMMIT_DIR + sha + "/" + checkOutFileName;
            File file = new File(filePath);
            if (!file.exists()) {
                System.out.println("File does not exist in that commit.");
                return ;
            }
            File dest = new File(checkOutFileName);

            if (!dest.exists()) {
                dest.mkdirs();
            }
            //checkout operator
            //copy the file in .gitlet/commit/sah into the root path
            //and change the original file
            //we use the head to find file
            try {
                Files.copy(file.toPath(), dest.toPath(), StandardCopyOption.REPLACE_EXISTING);
                //delete the staged files
            }catch (IOException e) {
                e.printStackTrace();
            }
        } else if (args.length == 4) {
            //checkout [commit id] -- [file name]


            String commitID = args[1];
            String subCommitID = commitID.substring(0,6);
            String checkOutFileName = args[3];
            //to check if this id exist
            boolean existFlag = false;
            for (String id : commitTree.keySet()) {
                id = id.substring(0,6);
                if (id.equals(subCommitID)) {
                    existFlag = true;
                    break;
                }
            }
            if (!existFlag) {
                System.out.println("No commit with that id exists.");
                return;
            }
            String filePath = GITLETFILE + COMMIT_DIR + commitID + "/" + checkOutFileName;
            File file = new File(filePath);
            if (!file.exists()) {
                System.out.println("File does not exist in that commit.");
                return ;
            }
            File dest = new File(checkOutFileName);

            if (!dest.exists()) {
                dest.mkdirs();
            }
            //checkout operator
            //copy the file in .gitlet/commit/XXsha into the root path
            //and change the original file
            //but this time, we find the file by using sha-1 code.
            try {
                Files.copy(file.toPath(), dest.toPath(), StandardCopyOption.REPLACE_EXISTING);
                //delete the staged files
            }catch (IOException e) {
                e.printStackTrace();
            }

        } else if (args.length == 2) {
           // checkout [branch name]
            //which means that now the currentBranch will change to new branch
            String newBranch = args[1];
            currentBranch = newBranch;
            updateHead();

        }
    }

    void gitletBranch(String branchName) {
        if (branches.values().contains(branchName)) {
            System.out.println("A branch with that name already exists.");
            return ;
        }

        branches.put(branchName,head.getID());

    }

    void gitletRmBranch(String branchName) {
        if (!branches.keySet().contains(branchName)) {
            System.out.println("A branch with that name does not exist.");
            return ;
        }
        if (currentBranch.equals(branchName)) {
            System.out.println("Cannot remove the current branch.");
            return ;
        }
        branches.remove(branchName);
    }

    void gitletReset(String commitID) {};

    void gitletMerge(String branchName) {};

    private void commitInit(String message) {
        Date currentDateObject = new Date();
        CNode initNode = new CNode();
        head = initNode;
        initNode.commit(""  , null, message,new HashSet<>(), currentDateObject);

        String toSHA = initNode.getID() + initNode.getParentsID() + initNode.getMessages() + initNode.getCommitDate();

        String commitSHA = Utils.sha1(toSHA);

        initNode.setID(commitSHA);
        commitTree.put(commitSHA,initNode);
        branches.put(currentBranch,commitSHA);



    }


    private void transferFromStagedToCommit(String sha) {
        for (String fileName: staged) {
            String shaPath = sha + "/";
            File src = new File(GITLETFILE + STAGINE_DIR + fileName);
            File dest = new File(GITLETFILE + COMMIT_DIR + shaPath + fileName);

            if (!dest.exists()) {
                dest.mkdirs();
            }
            //commit operator
            //copy the .gitlet/staged/ into the .gitlet/commit/
            try {
                Files.copy(src.toPath(), dest.toPath(), StandardCopyOption.REPLACE_EXISTING);
                //delete the staged files
                src.delete();
            }catch (IOException e) {
                e.printStackTrace();
            }

        }
    }


    private void scanUntrackedFiles() {
        File root = new File("./");
        String[] allFilesNames = root.list();
        for (String fileName : allFilesNames) {
            if (fileName.contains(".") && (fileName.charAt(0) != '.')) {
                untracked.add(fileName);
            }
        }
    }


    private void updateHead() {
        //use the sha-1 id to find the current head
        String currentHeadID = branches.get(currentBranch);
        head  = commitTree.get(currentHeadID);
    }

    private boolean compareFiles(File fa, File fb) {
        byte[] fab = Utils.readContents(fa);
        byte[] fbb = Utils.readContents(fb);
        String shaFa = Utils.sha1(fab);
        String shaFb = Utils.sha1(fbb);
        if (shaFa.equals(shaFb)) {
            return true;
        }
        return false;
    }


}
