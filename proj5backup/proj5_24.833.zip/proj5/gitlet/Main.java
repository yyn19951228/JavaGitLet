package gitlet;

import org.omg.PortableInterceptor.SYSTEM_EXCEPTION;

import java.io.*;

/** Driver class for Gitlet, the tiny stupid version-control system.
 *  @author You!
 */
public class Main {

    private static final String GITLETFILE = ".gitlet/";
    private static final String STAGINE_DIR = "staged/";
    private static final String COMMIT_DIR = "commit/";

    /** Usage: java gitlet.Main ARGS, where ARGS contains
     *  <COMMAND> <OPERAND> .... */
    public static void main(String... args) {
        // FILL THIS IN


        //there are 2 failure cases that need to be handled


        if (args.length == 0 ) {
            System.out.print("Please enter a command.");
            return ;
            //how to exit?????
        } else if (args[0].equals("init")) {
            if (args.length > 1) {
                System.out.println("Incorrect operands.");
                return ;
            }
            gitLet gl = new gitLet();
            gl.gitletInit();
            serialize(gl);
            return ;
        }
        gitLet gl = (gitLet) deserialize(GITLETFILE + "ser");
        if (args[0].equals("add")) {
            if (args.length > 2) {
                System.out.println("Incorrect operands.");
                return ;
            }
            gl.gitletAdd(args[1]);
        } else if (args[0].equals("commit")) {
            if (args.length > 2) {
                System.out.println("Incorrect operands.");
                return ;
            }
            gl.gitletCommit(args[1]);
        } else if (args[0].equals("rm")) {
            if (args.length > 2) {
                System.out.println("Incorrect operands.");
                return ;
            }
            gl.gitletRm(args[1]);
        } else if (args[0].equals("log")) {
            if (args.length > 1) {
                System.out.println("Incorrect operands.");
                return ;
            }
            gl.gitletLog();
        } else if (args[0].equals("global-log")) {
            if (args.length > 1) {
                System.out.println("Incorrect operands.");
                return ;
            }
            gl.gitletGlobalLog();
        } else if (args[0].equals("find")) {
            if (args.length > 2) {
                System.out.println("Incorrect operands.");
                return ;
            }
            gl.gitletFind(args[1]);
        } else if (args[0].equals("status")) {
            if (args.length > 1) {
                System.out.println("Incorrect operands.");
                return ;
            }
            gl.gitletStatus();
        } else if (args[0].equals("checkout")) {
            if (args.length > 4) {
                System.out.println("Incorrect operands.");
                return ;
            }
            gl.gitletCheckout(args);
        } else if (args[0].equals("branch")) {
            if (args.length > 2) {
                System.out.println("Incorrect operands.");
                return ;
            }
            gl.gitletBranch(args[1]);
        } else if (args[0].equals("rm-branch")) {
            if (args.length > 2) {
                System.out.println("Incorrect operands.");
                return ;
            }
            gl.gitletRmBranch(args[1]);
        } else if (args[0].equals("reset")) {
            if (args.length > 2) {
                System.out.println("Incorrect operands.");
                return ;
            }
            gl.gitletReset(args[1]);
        } else if (args[0].equals("merge")) {
            if (args.length > 2) {
                System.out.println("Incorrect operands.");
                return ;
            }
            gl.gitletMerge(args[1]);
        } else {
            System.out.print("No command with that name exists.");
        }

        serialize(gl);

    }

    static void serialize(Object o) {
        File toSer = new File(GITLETFILE + "ser");

        try {
            FileOutputStream fos = new FileOutputStream(toSer);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(o);
            oos.close();
        } catch(FileNotFoundException e) {
            toSer.mkdirs();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    static Object deserialize(String fileName) {
        Object objToRead = new Object();
        File fileToRead = new File(fileName);

        try {
            ObjectInputStream inp =
                    new ObjectInputStream(new FileInputStream(fileToRead));
            objToRead = (gitLet) inp.readObject();
            inp.close();
        } catch(IOException | ClassNotFoundException excp) {
            return null;
        }
        return objToRead;
    }

}
